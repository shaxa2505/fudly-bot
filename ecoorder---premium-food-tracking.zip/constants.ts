
import { ActiveOrder, OrderStatus, PastPurchase } from './types';

export const MOCK_ACTIVE_ORDER: ActiveOrder = {
  id: '#ORD-3942',
  storeName: 'Bellissimo Artisan',
  itemCount: 2,
  status: OrderStatus.IN_OVEN,
  imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDKPxrPDyYS-yqhu4sMCOAVoyHg7vnB-l-QbszZfpa16iGidLcIz_u7z24uapQ9KkX-rDrf2fwnUcYSgzhaGwvTWX7OJATmQP0C6e-GXKaQu8zwAjMXIYZmgxWW8r5mnnU4qDD9ntWNqlYCA-oYyRdtT3Gj0_67XXZ_o9BdGa9_XkFPvWtNMe0r7_JgC3APOthJhrI5WjskPVz2Uhw47wyvrTh3VZ-5fGbpc0X7UFoMRzS3aPRlGnuzzot7lp-BbOHW-TRSbYPfHQU'
};

export const MOCK_PAST_PURCHASES: PastPurchase[] = [
  {
    id: '1',
    storeName: 'Chaykhana No. 1',
    price: '124,000 UZS',
    date: 'Oct 24, 2023',
    status: 'Delivered',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD8lqww1j7bYZwM2_jtEvvqNo2D-iCGB73WT6paybkaW90AsC0eUTfb33LxS-Pbc7bG0dEPCZCq-UY2QUvUul7Tzfz6tVCWRJBh3xNBqujdSWxf5qTvBbgiXOg55_3QkS7ZK85vlPNlV1ECITap2YXGLHqTQngAbUYEScWKamOKSR_vazaMDfH2Y4koRk_degOHgHDufZqZdi-TrR3H1x0LW3vcJ0x49ypFR20XnanDWRPTZu6tSNDMHKRIs5F1A6SuHPR9TmdyCLs'
  },
  {
    id: '2',
    storeName: 'Gastro Burger',
    price: '89,500 UZS',
    date: 'Oct 21, 2023',
    status: 'Delivered',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAwQI0lw8psvY-KQVebrCbRNW49zM8wBNiy3xNUmpbfbzUitRROvmCkwE4B7s6setaZhIcJhuV6C0qDRAQuqjebU-5KPAdM03PesKAOiVNyrFccv3ECkPqF5Jy0ivjC5R3O4YdRhy1CvCanP6ZxYcNShPWTKavXOQc3RHt63pbAp8xJbs2EdRTyiErg-j7ovHES2mj0fPZzmyT5znTixzhFoKNVWRoX0rCxaGAy5LVr4kvV_eHhzGU1lgrcjnxzOzZ8zV7sn2PXh7s'
  },
  {
    id: '3',
    storeName: 'Eco Coffee',
    price: '45,000 UZS',
    date: 'Oct 19, 2023',
    status: 'Delivered',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCzbaso3PUIxr2oBA8kQd60vmdHXoezTUtIc2egf5EbzLzsaZrV71AYTe97n5yntJvyXaAJMfbJMD7a3BVhEfDG6cni_rdEk3nDmrBxprHEs7JfePeBMTbQ5jK2Dz3PnIev4AfdHsRg1Pf6PMvZIPly65nKiueOMioc2cgCFc6pyGXMS20LRMvM7BzPDxKuw4YlEywOrw7X5jictQdrD_vA9iYlZyAc1og0KpGrcBtVXhNiDN5c4obWXkPLGfnWxjZAZvA1z4BGHkc'
  }
];
