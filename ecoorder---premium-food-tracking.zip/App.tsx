
import React, { useState } from 'react';
import { Header } from './components/Header';
import { CurrentOrder } from './components/CurrentOrder';
import { PastPurchases } from './components/PastPurchases';
import { BottomNav } from './components/BottomNav';
import { TabType } from './types';
import { MOCK_ACTIVE_ORDER, MOCK_PAST_PURCHASES } from './constants';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('active');

  return (
    <div className="min-h-screen flex flex-col pb-32">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="px-5 py-6 flex-grow">
        {activeTab === 'active' ? (
          <>
            <CurrentOrder order={MOCK_ACTIVE_ORDER} />
            <PastPurchases purchases={MOCK_PAST_PURCHASES} />
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 opacity-40">
            <span className="material-symbols-outlined !text-6xl mb-4">history</span>
            <p className="text-sm font-medium uppercase tracking-widest">Order History Empty</p>
          </div>
        )}

        {/* Sustainable Choice CTA */}
        <div className="mt-12 border-t border-premium-border pt-8">
          <button className="w-full bg-premium-accent p-6 flex items-center justify-between text-left transition-transform active:scale-[0.98]">
            <div className="pr-4">
              <h4 className="text-white text-[12px] font-bold uppercase tracking-[0.1em] mb-1">Sustainable Choice</h4>
              <p className="text-white/70 text-[11px] leading-relaxed">View surplus availability in your district.</p>
            </div>
            <span className="material-symbols-outlined text-white">arrow_forward</span>
          </button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default App;
