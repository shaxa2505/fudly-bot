
export enum OrderStatus {
  CONFIRMED = 'CONFIRMED',
  IN_OVEN = 'IN_OVEN',
  PICKUP = 'PICKUP'
}

export interface ActiveOrder {
  id: string;
  storeName: string;
  itemCount: number;
  status: OrderStatus;
  imageUrl: string;
}

export interface PastPurchase {
  id: string;
  storeName: string;
  price: string;
  date: string;
  status: 'Delivered' | 'Cancelled';
  imageUrl: string;
}

export type TabType = 'active' | 'history';
