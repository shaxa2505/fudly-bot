
import React from 'react';
import { TabType } from '../types';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  return (
    <header className="sticky top-0 z-50 bg-[#F9F9F9]/90 backdrop-blur-xl border-b border-premium-border/50 px-5 pt-12 pb-4">
      <div className="flex items-center justify-between mb-6">
        <button className="flex items-center justify-center p-1">
          <span className="material-symbols-outlined">arrow_back_ios</span>
        </button>
        <h1 className="text-[15px] font-semibold tracking-tighter uppercase">Orders</h1>
        <button className="flex items-center justify-center p-1">
          <span className="material-symbols-outlined">info</span>
        </button>
      </div>
      <div className="flex border-b border-premium-border">
        <button 
          onClick={() => setActiveTab('active')}
          className={`relative flex-1 py-3 text-[11px] font-semibold uppercase tracking-widest transition-colors ${activeTab === 'active' ? 'text-premium-text' : 'text-premium-muted'}`}
        >
          Active (1)
          {activeTab === 'active' && (
            <div className="absolute bottom-0 left-0 w-full h-[2px] bg-premium-accent"></div>
          )}
        </button>
        <button 
          onClick={() => setActiveTab('history')}
          className={`relative flex-1 py-3 text-[11px] font-semibold uppercase tracking-widest transition-colors ${activeTab === 'history' ? 'text-premium-text' : 'text-premium-muted'}`}
        >
          History
          {activeTab === 'history' && (
            <div className="absolute bottom-0 left-0 w-full h-[2px] bg-premium-accent"></div>
          )}
        </button>
      </div>
    </header>
  );
};
