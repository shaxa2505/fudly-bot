
import React from 'react';

export const BottomNav: React.FC = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-premium-border px-8 pb-8 pt-4 flex justify-between items-center z-50">
      <button className="flex flex-col items-center gap-1.5 opacity-30 hover:opacity-100 transition-opacity">
        <span className="material-symbols-outlined">grid_view</span>
        <span className="text-[9px] font-bold uppercase tracking-widest">Store</span>
      </button>
      <button className="flex flex-col items-center gap-1.5 opacity-30 hover:opacity-100 transition-opacity">
        <span className="material-symbols-outlined">search</span>
        <span className="text-[9px] font-bold uppercase tracking-widest">Search</span>
      </button>
      <button className="flex flex-col items-center gap-1.5 text-premium-accent">
        <span className="material-symbols-outlined filled">receipt_long</span>
        <span className="text-[9px] font-bold uppercase tracking-widest">Orders</span>
      </button>
      <button className="flex flex-col items-center gap-1.5 opacity-30 hover:opacity-100 transition-opacity">
        <span className="material-symbols-outlined">person</span>
        <span className="text-[9px] font-bold uppercase tracking-widest">Account</span>
      </button>
      <div className="fixed bottom-1 left-1/2 -translate-x-1/2 w-32 h-1 bg-[#2D2D2D] rounded-full z-[60] opacity-20 pointer-events-none"></div>
    </nav>
  );
};
