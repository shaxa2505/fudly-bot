
import React from 'react';
import { PastPurchase } from '../types';

interface PastPurchasesProps {
  purchases: PastPurchase[];
}

export const PastPurchases: React.FC<PastPurchasesProps> = ({ purchases }) => {
  return (
    <div>
      <h2 className="text-[10px] font-bold uppercase tracking-[0.15em] text-premium-muted mb-4">Past Purchases</h2>
      <div className="space-y-3">
        {purchases.map((purchase) => (
          <div key={purchase.id} className="bg-white border border-premium-border p-4 flex items-center gap-4 hover:shadow-sm transition-shadow">
            <div className="w-12 h-12 flex-shrink-0 grayscale">
              <img 
                alt={purchase.storeName} 
                className="w-full h-full object-cover rounded-sm" 
                src={purchase.imageUrl} 
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-baseline mb-0.5">
                <h4 className="text-[13px] font-bold truncate tracking-tight">{purchase.storeName}</h4>
                <span className="text-[11px] font-medium">{purchase.price}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-premium-muted">{purchase.date}</span>
                <span className="w-[3px] h-[3px] rounded-full bg-premium-border"></span>
                <span className="text-[10px] text-premium-accent font-semibold uppercase tracking-tighter">
                  {purchase.status}
                </span>
              </div>
            </div>
            <button className="ml-2 p-2 border border-premium-border hover:bg-premium-bg transition-colors">
              <span className="material-symbols-outlined !text-[18px]">repartition</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
