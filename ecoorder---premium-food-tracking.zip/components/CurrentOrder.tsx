
import React from 'react';
import { ActiveOrder, OrderStatus } from '../types';

interface CurrentOrderProps {
  order: ActiveOrder;
}

export const CurrentOrder: React.FC<CurrentOrderProps> = ({ order }) => {
  const getStatusIndex = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.CONFIRMED: return 0;
      case OrderStatus.IN_OVEN: return 1;
      case OrderStatus.PICKUP: return 2;
      default: return 0;
    }
  };

  const currentIndex = getStatusIndex(order.status);

  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-[10px] font-bold uppercase tracking-[0.15em] text-premium-muted">Current Order</h2>
      </div>
      <div className="bg-white border border-premium-border rounded-lg overflow-hidden transition-all duration-300 shadow-sm">
        <div className="p-5">
          <div className="flex gap-4 mb-6">
            <img 
              alt={order.storeName} 
              className="w-16 h-16 object-cover rounded-sm grayscale-[0.2]" 
              src={order.imageUrl}
            />
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-bold tracking-tight">{order.storeName}</h3>
                  <p className="text-[11px] text-premium-muted mt-1 tracking-wide">
                    ID: {order.id} • {order.itemCount} Items
                  </p>
                </div>
                <span className="text-[10px] font-bold text-premium-accent border border-premium-accent/20 px-2 py-0.5 tracking-tighter">
                  PREPARING
                </span>
              </div>
            </div>
          </div>
          
          <div className="px-1">
            <div className="h-0.5 bg-premium-border relative my-5">
              <div 
                className="absolute top-0 left-0 h-full bg-premium-accent transition-all duration-500" 
                style={{ width: `${currentIndex * 50}%` }}
              />
              <div className={`w-1.5 h-1.5 rounded-full absolute top-1/2 -translate-y-1/2 left-0 ${currentIndex >= 0 ? 'bg-premium-accent' : 'bg-premium-border'}`} />
              <div className={`w-1.5 h-1.5 rounded-full absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 ${currentIndex >= 1 ? 'bg-premium-accent' : 'bg-premium-border'}`} />
              <div className={`w-1.5 h-1.5 rounded-full absolute top-1/2 -translate-y-1/2 right-0 ${currentIndex >= 2 ? 'bg-premium-accent' : 'bg-premium-border'}`} />
            </div>
            <div className="flex justify-between mt-2">
              <span className={`text-[9px] font-bold uppercase tracking-wider ${currentIndex >= 0 ? 'text-premium-accent' : 'text-premium-muted'}`}>Confirmed</span>
              <span className={`text-[9px] font-bold uppercase tracking-wider text-center ${currentIndex >= 1 ? 'text-premium-accent' : 'text-premium-muted'}`}>In Oven</span>
              <span className={`text-[9px] font-bold uppercase tracking-wider text-right ${currentIndex >= 2 ? 'text-premium-accent' : 'text-premium-muted'}`}>Pickup</span>
            </div>
          </div>

          <div className="mt-8 flex gap-3">
            <button className="flex-1 bg-premium-accent text-white text-[11px] font-bold uppercase tracking-widest py-4 transition-colors hover:bg-black">
              View Details
            </button>
            <button className="px-5 border border-premium-border text-premium-text flex items-center justify-center hover:bg-premium-bg transition-colors">
              <span className="material-symbols-outlined">chat_bubble</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
