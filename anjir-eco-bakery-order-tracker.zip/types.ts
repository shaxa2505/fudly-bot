
export type OrderStatus = 'Confirmed' | 'Prepared' | 'Ready';

export interface Merchant {
  name: string;
  address: string;
  phone: string;
  lat: number;
  lng: number;
  mapImageUrl: string;
}

export interface OrderItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
}

export interface OrderData {
  id: string;
  status: OrderStatus;
  pickupTime: string;
  merchant: Merchant;
  items: OrderItem[];
  subtotal: number;
  rescueDiscount: number;
  pickupCode: string;
}
