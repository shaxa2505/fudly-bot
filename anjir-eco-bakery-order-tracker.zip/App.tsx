
import React, { useState } from 'react';
import { Header } from './components/Header';
import { OrderHero } from './components/OrderHero';
import { MerchantSection } from './components/MerchantSection';
import { SelectionList } from './components/SelectionList';
import { FinancialSummary } from './components/FinancialSummary';
import { PickupControls } from './components/PickupControls';
import { OrderData } from './types';

const MOCK_ORDER: OrderData = {
  id: "AW-8293",
  status: "Ready",
  pickupTime: "21:30",
  merchant: {
    name: "Eco-Bakery \"Anjir\"",
    address: "Shota Rustaveli St, 24, Tashkent",
    phone: "+998 00 000 0000",
    lat: 41.311081,
    lng: 69.240562,
    mapImageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuA5w23gS3WkH1Y2jwhvbyuF_3R0n0O1dtzFhCBFeagMyeOMFmsfwTNau6-msS788eYAtvbizHTrPunj9kwgEdnYFnjppJoN1jQkbJt6-HgOjl6k_TlCKAhsLZSKREDKolyrYANAm2467pfPE-kMuWJdY7ZVt7Ms6tEvhOn0wCyd-0C4U97bSkUDqg3W-gitmZi5ubH2Diul5_16PwVI_jl_0OqpJCBYpygHM64Nak7EcCyqC8J4sGE9GBtl875-SJC8j_ZTJ9Rf3Bk"
  },
  items: [
    {
      id: "1",
      name: "Mix Pastry Box (M)",
      description: "Artisanal selection from daily surplus",
      price: 28000,
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuACrAYLiehNmQdiYSbRWwX6WC9N9hcM-4JOz9HaR7dqqLOmQ8XuHcPJztxF90KxOzfYiCVWfnICZAVM9bs3T3UsmgwqOUINJjUNKBEf2-fC8CJOnGNivPoCgr-EtPKGuZLqrLf7YD24paoixmuOc6Ywa_2FcYieU_vlBcDuwPjhTWmTA95zqksUi0xOKuCI466-ehdLcOoyw0hXA1X52V-74Qwh0vS1_VZsCdv_kJ7bzbOPHd55PxFoO_r_LwZcepn-0RTBkub06Gk"
    },
    {
      id: "2",
      name: "Surprise Cupcake",
      description: "Single unit organic pastry",
      price: 7000,
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDI5cGnV4_shmSm_UXzxaCHON0t0IfPsAHYkvJwKMaWa_FEbvcXbJNPR3QHQhWMhDfIZJ6JSHuLpnbze3ismQmwl9cDQaSxTgYYlUtPhInKNnwnyNeO6LTKZvLZqOxyR_Xt59f4hr8FhfPcPs-xEuhNUGW5fTJyQP86pHAEtUv5njWxqr2v1geegQekSxEnoUvfuGWL85ZcHyQHgyjveZMAR_5HTU7cFnREGb45xilkQPFFz0eJrfCVJkFw56VRza6mZp362E8qkUI"
    }
  ],
  subtotal: 93000,
  rescueDiscount: 58000,
  pickupCode: "62 — 84"
};

const App: React.FC = () => {
  const [order] = useState<OrderData>(MOCK_ORDER);

  return (
    <div className="min-h-screen bg-white pb-60">
      <Header id={order.id} />
      
      <main className="max-w-md mx-auto pt-24 px-6">
        <OrderHero 
          status={order.status} 
          pickupTime={order.pickupTime} 
        />
        
        <div className="mt-10 pt-10 border-t border-slate-100">
          <MerchantSection merchant={order.merchant} />
        </div>

        <div className="mt-12">
          <SelectionList items={order.items} />
        </div>

        <div className="mt-12 pt-8 border-t border-slate-900/5">
          <FinancialSummary 
            subtotal={order.subtotal} 
            discount={order.rescueDiscount} 
          />
        </div>

        <div className="mt-12 text-center pb-12">
          <button className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-charcoal transition-colors">
            Terms & Conditions • Support
          </button>
        </div>
      </main>

      <PickupControls 
        pickupCode={order.pickupCode} 
        onGetDirections={() => console.log('Directions')} 
        onOrderReceipt={() => console.log('Receipt')} 
      />
    </div>
  );
};

export default App;
