
import React from 'react';
import { Merchant } from '../types';

interface MerchantSectionProps {
  merchant: Merchant;
}

export const MerchantSection: React.FC<MerchantSectionProps> = ({ merchant }) => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-bold tracking-tight text-charcoal mb-1 uppercase leading-tight">
            {merchant.name}
          </h3>
          <p className="text-sm text-slate-500 font-medium">{merchant.address}</p>
        </div>
        <button className="w-10 h-10 border border-slate-200 flex items-center justify-center hover:bg-slate-50 transition-colors">
          <span className="material-symbols-outlined text-slate-600">call</span>
        </button>
      </div>

      <div className="relative w-full aspect-[21/9] bg-slate-100 grayscale opacity-80 border border-slate-100 overflow-hidden">
        <img 
          alt="Map location" 
          className="w-full h-full object-cover" 
          src={merchant.mapImageUrl} 
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-3 h-3 bg-forest rounded-full ring-8 ring-forest/10 animate-pulse"></div>
        </div>
      </div>
    </div>
  );
};
