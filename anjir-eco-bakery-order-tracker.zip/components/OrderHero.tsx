
import React from 'react';
import { OrderStatus } from '../types';

interface OrderHeroProps {
  status: OrderStatus;
  pickupTime: string;
}

export const OrderHero: React.FC<OrderHeroProps> = ({ status, pickupTime }) => {
  const steps: OrderStatus[] = ['Confirmed', 'Prepared', 'Ready'];
  const currentIndex = steps.indexOf(status);

  return (
    <section className="text-center">
      <h2 className="text-3xl font-light tracking-tight text-forest mb-2">Ready for Collection</h2>
      <p className="text-sm text-slate-500 mb-8 font-medium">Please pick up your order by {pickupTime}</p>
      
      <div className="relative px-4">
        {/* Progress Line */}
        <div className="absolute top-[5px] left-4 right-4 h-[1px] bg-slate-100">
          <div 
            className="h-full bg-forest transition-all duration-700" 
            style={{ width: `${(currentIndex / (steps.length - 1)) * 100}%` }}
          />
        </div>

        {/* Status Steps */}
        <div className="flex justify-between items-start relative">
          {steps.map((step, idx) => {
            const isActive = idx <= currentIndex;
            const isLatest = idx === currentIndex;
            
            return (
              <div key={step} className="flex flex-col items-center">
                <div className={`w-2.5 h-2.5 rounded-full border-4 border-white mb-3 transition-colors duration-300 ${isActive ? 'bg-forest' : 'bg-slate-200'}`} />
                <span className={`text-[9px] font-bold uppercase tracking-widest transition-colors duration-300 ${isActive ? (isLatest && step === 'Ready' ? 'text-forest' : 'text-slate-400') : 'text-slate-300'}`}>
                  {step}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
