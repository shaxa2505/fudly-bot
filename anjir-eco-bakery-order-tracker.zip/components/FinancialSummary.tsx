
import React from 'react';

interface FinancialSummaryProps {
  subtotal: number;
  discount: number;
}

export const FinancialSummary: React.FC<FinancialSummaryProps> = ({ subtotal, discount }) => {
  const total = subtotal - discount;

  return (
    <div className="space-y-3">
      <div className="flex justify-between text-sm text-slate-500 font-medium">
        <span>Subtotal</span>
        <span className="text-charcoal">{subtotal.toLocaleString()} UZS</span>
      </div>
      
      <div className="flex justify-between text-sm text-forest font-bold">
        <span>Rescue Discount</span>
        <span>-{discount.toLocaleString()} UZS</span>
      </div>

      <div className="flex justify-between items-center pt-4">
        <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Total Charged</span>
        <span className="text-2xl font-light text-forest tracking-tighter">
          {total.toLocaleString()} UZS
        </span>
      </div>
    </div>
  );
};
