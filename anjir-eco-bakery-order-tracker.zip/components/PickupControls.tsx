
import React from 'react';

interface PickupControlsProps {
  pickupCode: string;
  onGetDirections: () => void;
  onOrderReceipt: () => void;
}

export const PickupControls: React.FC<PickupControlsProps> = ({ 
  pickupCode, 
  onGetDirections, 
  onOrderReceipt 
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-6 pt-5 pb-10 z-50">
      <div className="max-w-md mx-auto">
        <div className="mb-5 border border-slate-200 flex items-center justify-between p-4">
          <div className="flex flex-col">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Pick-up Code</span>
            <span className="text-2xl font-light tracking-[0.2em] text-charcoal">{pickupCode}</span>
          </div>
          <div className="w-12 h-12 flex items-center justify-center border-l border-slate-100 pl-4">
            <span className="material-symbols-outlined text-slate-300 text-3xl">qr_code_2</span>
          </div>
        </div>

        <div className="flex gap-3">
          <button 
            onClick={onGetDirections}
            className="flex-1 bg-forest text-white py-4 text-xs font-bold uppercase tracking-widest active:bg-slate-800 transition-colors"
          >
            Get Directions
          </button>
          <button 
            onClick={onOrderReceipt}
            className="flex-1 border border-charcoal text-charcoal py-4 text-xs font-bold uppercase tracking-widest active:bg-slate-50 transition-colors"
          >
            Order Receipt
          </button>
        </div>
      </div>
    </div>
  );
};
