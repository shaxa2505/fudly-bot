
import React from 'react';
import { OrderItem } from '../types';

interface SelectionListProps {
  items: OrderItem[];
}

export const SelectionList: React.FC<SelectionListProps> = ({ items }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-slate-100 pb-2">
        <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Your Selection</h4>
        <span className="text-[10px] font-bold text-slate-400 uppercase">{items.length} Items</span>
      </div>

      <div className="space-y-8">
        {items.map((item) => (
          <div key={item.id} className="flex gap-5">
            <div className="w-14 h-14 bg-slate-50 flex-shrink-0">
              <img 
                alt={item.name} 
                className="w-full h-full object-cover grayscale" 
                src={item.image} 
              />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start mb-1">
                <p className="font-bold text-sm text-charcoal tracking-tight uppercase">{item.name}</p>
                <p className="text-sm font-bold text-forest whitespace-nowrap ml-4">
                  {item.price.toLocaleString()} UZS
                </p>
              </div>
              <p className="text-xs text-slate-400 font-medium italic">{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
