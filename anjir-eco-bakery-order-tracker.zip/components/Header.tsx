
import React from 'react';

interface HeaderProps {
  id: string;
}

export const Header: React.FC<HeaderProps> = ({ id }) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100 px-5 py-4 flex items-center justify-between">
      <button className="flex items-center justify-center p-2 -ml-2">
        <span className="material-symbols-outlined text-[22px]">arrow_back_ios</span>
      </button>
      
      <div className="text-center">
        <h1 className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400 mb-0.5">Order Confirmation</h1>
        <p className="text-sm font-semibold tracking-tight text-forest">ID #{id}</p>
      </div>

      <button className="flex items-center justify-center p-2 -mr-2">
        <span className="material-symbols-outlined text-[22px]">more_horiz</span>
      </button>
    </header>
  );
};
